import React, { useEffect, useMemo, useState } from 'react';
import CreateProductWeightStandardJsx from '../template/CreateProductWeightStandardJsx';
import { useGetProducts } from '../../../../product_wareHouse/Api/productsApi';
import { useGetProfile } from '../../../../../hooks/profile/profile';
import { useCreateProductionWeightStandard } from '../../../Api/productWeightStandardForm';

function CreateProductWeightStandard({ openCreateModal, setOpenCreateModal }) {
  const [form, setForm] = useState({
    formDate: '',
    productName: '',
    productCode: '',
    companyName: '',
    isMachineLine1: 'ماشین IS خط 1',
    isMachineLine2: 'ماشین IS خط 2',
    isMachineLine3: 'ماشین IS خط 3',
    productWeightLine1: 0,
    productWeightLine2: 0,
    productWeightLine3: 0,
    weightToleranceLine1: '',
    weightToleranceLine2: '',
    weightToleranceLine3: '',
    recommendedLine1: '',
    recommendedLine2: '',
    recommendedLine3: '',
    notes: '',
  });

  
  const { data: profile } = useGetProfile();

  const getCompany = profile?.data?.companyRoles?.[0]?.companyName;

  useEffect(() => {
    if (profile?.data) {
      setForm((p) => ({
        ...p,
        companyName: getCompany || 'کاویان جار ساچی',
      }));
    }
  }, [profile]);

  const closeHandler = () => {
    setOpenCreateModal(false);
  };

  const { data: product } = useGetProducts();
  const [searchProducts, setSearchProducts] = useState('');

  const getProducts = useMemo(() => {
    const none = { id: '', name: 'انتخاب  محصول' };
    return [
      none,
      ...(product ?? []).map((p) => ({
        id: p.id,
        name: p.productName,
        code: p.productCode,
      })),
    ];
  }, [product]);

  const filterProducts = useMemo(() => {
    const q = searchProducts.trim().toLowerCase();
    if (!q) return getProducts;

    return getProducts.filter((p) => (p?.name || '').toLowerCase().includes(q));
  }, [searchProducts, getProducts]);

  const selectedProducts = useMemo(() => {
    return getProducts.find((p) => p.id === (form.id || '')) || getProducts[0];
  }, [getProducts, form.id]);

  const createReport = useCreateProductionWeightStandard();

  const submitHandler = (e) => {
    e.preventDefault();

    if (!form.formDate) {
      toast.warning('لطفا تاریخ را انتخاب کنید');
      return;
    }

    createReport.mutate(form, {
      onSuccess: () => {
        setOpenCreateModal(false);
      },
    });
  };

  return (
    <div
      className={`fixed inset-0 z-50 flex h-screen items-center justify-center overflow-auto p-4 transition-opacity duration-300 ${
        openCreateModal
          ? 'pointer-events-auto opacity-100 '
          : 'pointer-events-none opacity-0'
      }`}
    >
      <div
        className="absolute inset-0 bg-black/50 backdrop-blur-[2px]"
        onClick={closeHandler}
      />
      <div
        className={`relative flex max-h-[90vh] min-h-0 max-w-[80vw] transform flex-col overflow-hidden rounded-[15px] bg-linear-to-bl from-black to-gray-600 p-6 text-white shadow-2xl transition-all duration-300 max-2xl:scale-95 max-md:h-160 ${
          openCreateModal
            ? 'translate-y-0 scale-100 opacity-100'
            : '-translate-y-10 scale-0 opacity-0'
        }`}
      >
        <CreateProductWeightStandardJsx
          closeHandler={closeHandler}
          submitHandler={submitHandler}
          form={form}
          setForm={setForm}
          product={product}
          searchProducts={searchProducts}
          setSearchProducts={setSearchProducts}
          getProducts={getProducts}
          filterProducts={filterProducts}
          selectedProducts={selectedProducts}
        />
      </div>
    </div>
  );
}

export default CreateProductWeightStandard;
